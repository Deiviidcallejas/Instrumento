package Ejercicio8;

public class Principal {

	public static void main(String[] args) {
		new InterfazGrafica().setVisible(true);

	}

}
