import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JTextField;

public class Logica {
    private JButton btnTraspasa1;
    private JButton btnTraspasa2;
    private JTextField txtTexto1;
    private JTextField txtTexto2;

    public Logica(JButton btnTraspasa1, JButton btnTraspasa2, JTextField txtTexto1, JTextField txtTexto2) {
        this.btnTraspasa1 = btnTraspasa1;
        this.btnTraspasa2 = btnTraspasa2;
        this.txtTexto1 = txtTexto1;
        this.txtTexto2 = txtTexto2;
    }

    public void configurarEventos() {
        btnTraspasa1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                txtTexto1.setText(txtTexto2.getText());
            }
        });

        btnTraspasa2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                txtTexto2.setText(txtTexto1.getText());
            }
        });
    }
}

