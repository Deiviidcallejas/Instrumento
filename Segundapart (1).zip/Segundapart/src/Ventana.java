import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Color;

public class Ventana extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtTexto1;
	private JTextField txtTexto2;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;

	public Ventana() {
		iniciarComponentes();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
	
	}
	public void iniciarComponentes() {
		contentPane = new JPanel();
		contentPane.setBackground(new Color(211, 211, 211));
		contentPane.setForeground(new Color(211, 211, 211));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtTexto1 = new JTextField();
		txtTexto1.setBounds(52, 60, 118, 28);
		contentPane.add(txtTexto1);
		txtTexto1.setColumns(10);
		
		txtTexto2 = new JTextField();
		txtTexto2.setBounds(264, 60, 118, 28);
		contentPane.add(txtTexto2);
		txtTexto2.setColumns(10);
		
		JButton btnTraspasa1 = new JButton("Traspasa 2");
		btnTraspasa1.setBounds(52, 147, 118, 28);
		contentPane.add(btnTraspasa1);
		
		JButton btnTraspasa2 = new JButton("Traspasa 1");
		btnTraspasa2.setBounds(264, 147, 118, 28);
		contentPane.add(btnTraspasa2);
		
		lblNewLabel = new JLabel("Texto 1");
		lblNewLabel.setBounds(84, 28, 51, 33);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Texto 2");
		lblNewLabel_1.setBounds(302, 34, 46, 20);
		contentPane.add(lblNewLabel_1);
		
		Logica logica = new Logica(btnTraspasa1, btnTraspasa2, txtTexto1, txtTexto2);
		logica.configurarEventos();
	 

		
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
