package instrumento;

public class Principal {
    public static void main(String[] args) {
        Interfaz interfaz = new Interfaz();

        // Muestra la interfaz
        interfaz.setVisible(true);
    }
}
