package instrumento;

import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Logica {
    private JTextField campo_nombre;
    private JTextField Campo_ciudad;

    public Logica(JTextField campo_nombre, JTextField Campo_ciudad) {
        this.campo_nombre = campo_nombre;
        this.Campo_ciudad = Campo_ciudad;
    }

    public void configurarEventos(JButton btnVisualizarNombre, JButton btnOcultarNombre, JButton btnVisualizarCiudad, JButton btnOcultarCiudad) {
        btnVisualizarNombre.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                campo_nombre.setVisible(true);
            }
        });

        btnOcultarNombre.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                campo_nombre.setVisible(false);
            }
        });

        btnVisualizarCiudad.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Campo_ciudad.setVisible(true);
            }
        });

        btnOcultarCiudad.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Campo_ciudad.setVisible(false);
            }
        });
    }
}

