package instrumento;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.JButton;

public class Interfaz extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField campo_nombre;
	private JTextField Campo_ciudad;



	public Interfaz() {
	
		iniciarcomponentes();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
	}
    public void iniciarcomponentes() {
	
    	contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("Nombre :");
		lblNewLabel.setBounds(24, 33, 55, 20);
		setBounds(100, 100, 450, 300);
		contentPane.setLayout(null);
		contentPane.add(lblNewLabel);
		
		campo_nombre = new JTextField();
		campo_nombre.setBounds(117, 33, 131, 20);
		contentPane.add(campo_nombre);
		setBounds(100, 100, 450, 300);
		campo_nombre.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Ciudad :");
		lblNewLabel_1.setBounds(24, 80, 55, 16);
		contentPane.add(lblNewLabel_1);
		
		Campo_ciudad = new JTextField();
		Campo_ciudad.setBounds(117, 78, 131, 20);
		contentPane.add(Campo_ciudad);
		Campo_ciudad.setColumns(10);
		
		JButton btnVisualizarNombre = new JButton("Visualizar Nombre");
		btnVisualizarNombre.setBounds(12, 143, 144, 35);
		contentPane.add(btnVisualizarNombre);
		
		JButton btnVisualizarCiudad = new JButton("Visualizar Ciudad");
		btnVisualizarCiudad.setBounds(208, 143, 150, 35);
		contentPane.add(btnVisualizarCiudad);
		
		JButton btnOcultarNombre = new JButton("Ocultar Nombre");
		btnOcultarNombre.setBounds(12, 208, 144, 35);
		contentPane.add(btnOcultarNombre);
		
		JButton btnOcultarCiudad = new JButton("Ocultar Ciudad");
		btnOcultarCiudad.setBounds(208, 208, 150, 35);
		contentPane.add(btnOcultarCiudad);
		Logica logica = new Logica(campo_nombre, Campo_ciudad);
        logica.configurarEventos(btnVisualizarNombre, btnOcultarNombre, btnVisualizarCiudad, btnOcultarCiudad);

	}
    
	@Override
	public void actionPerformed(ActionEvent e) {
	
		
	}
}